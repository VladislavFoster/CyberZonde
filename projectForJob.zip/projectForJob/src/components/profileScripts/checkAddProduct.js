window.addEventListener('DOMContentLoaded', ()=>{
	const form = document.querySelector('#addProduct');
	// form.addEventListener('submit', formSend);

	// async function formSend(event){
	// 	event.preventDefault();

	// 	let error = formValidate(form); 

	// 	let formData = new FormData(form);

	// 	if(error == 0){
			
	// 		form.classList.add('sending')
			
	// 		let response = await fetch('./src/includes/addProduct.php', {
	// 			method: 'POST',
	// 			body: formData
	// 		})
	// 		//при успешной отправке запроса будет братся логика из файла 
			
	// 		if(response.ok){
	// 			//логика сработает если отправка сообщения была успешна
	// 			let result = await response.json();
	// 			alert(result.message);
	// 			//очищает информацию после её отвправления в сообщении
	// 			form.reset();
	// 			//после отправки сообщения удаляет гифку lazy loading
	// 			form.classList.remove('sending');
	// 		}else{
	// 			alert('Ошибка');
	// 			//после выявления ошибки удаляет гифку lazy loading
	// 			form.classList.remove('sending');
	// 		}
	// 	}else{
	// 		// сюда можно ввести действия если будут ошибки при заполнении
	// 		alert('Ошибка');
	// 	}

	// }

	// function formValidate(form){
	// 	let error = 0;
	// 	//получает все элементы с классом req. Этот класс необходимо добавить в каждый input, который должен быть обязательно заполнен информацией
	// 	let formReq = document.querySelectorAll('.req');
	// 	//проверяет каждый input с классов req на заполнение
	// 	for(let i = 0; i < formReq.length; i++){
	// 		let input = formReq[i];
	// 		//если не были заполненны данные в форме при повторном заполнении 
	// 		//удаляются классы говорящие об этой ошибке
	// 		formRemoveError(input);
	// 		//если тест на корректное заполнение почты не пройден, выдаёт ошибку
	// 		if(input.classList.contains('email')){
	// 			if(emailTest(input)){
	// 				formAddError(input);
	// 				error++;
	// 			}
	// 		}//если не будет подтверждено согласие на обработку данных, выдаёт 			ошибку
	// 		else if(input.getAttribute("type") === "checkbox" && input.checked 	=== false){
	// 			formAddError(input);
	// 			error++;
	// 		}//Проверяет заполнена ли строка вообще
	// 		else{
	// 			if(input.value == ''){
	// 				formAddError(input);
	// 				error++;
	// 			}
	// 		}
	// 	}
	// 	//возвращает количество ошибок для обработки данных в функции formSend
	// 	return error;
	// }
	// //добавляет класс error если в input с классом req не были заполнены данные
	// function formAddError(input){
	// 	input.parentElement.classList.add('error');
	// 	input.classList.add('error');
	// }
	// //удаляет класс error если в input с классом req были заполнены данные
	// function formRemoveError(input){
	// 	input.parentElement.classList.remove('error');
	// 	input.classList.remove ('error');
	// }
	// //фунция проверяет с помощью регулярного выражения присутствует ли @ и точка
	// function emailTest(input){
	// 	return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
	// }

    const formImage = document.querySelector('#addImg');
    const imgPreview = document.getElementById('imgPrev');
    
    formImage.addEventListener('change', ()=>{
        uploadFile(formImage.files[0]);
    });

    function uploadFile(file){
        if(!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)){
            alert('Разрешены только изображения');
            formImage.value = '';
            return;
        }

        if(file.size > 2 * 1024 * 1024){
            alert('Файл должен быть меньше 2 МБ');
            return;
        }

        let reader = new FileReader();
        reader.onload = function(e){
			if(imgPreview.childElementCount == 0){
				imgPreview.insertAdjacentHTML('afterbegin', `
					<div class="addedImg">
						<img class="addImg" src="${e.target.result}" alt="">
						<img class="deleteImg" src="./src/assets/imgs/deleteImg.png" alt="">
						<img class="watchImg" src="./src/assets/imgs/watchImg.png" alt="">
						<img class="redCupImg" src="./src/assets/imgs/redCupImg.png" alt="">
				</div>`);
			}else{
				imgPreview.insertAdjacentHTML('beforeend', `
					<div class="addedImg">
						<img class="addImg" src="${e.target.result}" alt="">
						<img class="deleteImg" src="./src/assets/imgs/deleteImg.png" alt="">
						<img class="watchImg" src="./src/assets/imgs/watchImg.png" alt="">
						<img class="blueCupImg" src="./src/assets/imgs/blueCupImg.png" alt="">
				</div>`);
			}
            
        }

        reader.onerror = function(e){
            alert('Ошибка');
        }

        reader.readAsDataURL(file)
    }
})